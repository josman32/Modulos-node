/*const XLSX = require('xlsx');

function leerArchivo(ruta){
    const workbook = XLSX.readFile(ruta);
    const workbookSheets = workbook.SheetNames;

    //console.log(workbookSheets);
    const sheet = workbookSheets[0];
    const dataExcel = XLSX.utils.sheet_to_json(workbook.Sheets[sheet]);

    console.log(dataExcel);
}

leerArchivo('DAX.xlsx')*/

//No logre editar el archivo xlsx por eso lo comente y lo ise con un archivo txt

const { writeFile } = require("fs");
const fs = require("fs/promises");
const path = require("path")

const pathTexto = path.join(__dirname, "./Datos.txt");
//Aqui edito el archivo txt
//fs.writeFileSync(pathTexto, "Aqui escribo el archivo", "utf-8");
const readFileFunc = async () => {
    const texto = await fs.readFile(pathTexto, "utf-8");
    console.log(texto);
};
//Aqui nuevamente editando el archivo de otra manera
const writeFileFunc = async () => {
    await fs.writeFile(
        pathTexto,
        "Editando nuevamente el archivo", "utf-8"
    );
};
writeFileFunc();
//readFileFunc();